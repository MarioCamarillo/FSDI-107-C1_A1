import logo from './logo.svg';
import './App.css';
import Navbar from './components/navbar';
import Footer from './components/Footer';



function App() {
  return (
    <div className="App">
      <Navbar></Navbar>
      <p>Welcome here</p>
      <Footer></Footer>
    </div>
  );
}

export default App;
