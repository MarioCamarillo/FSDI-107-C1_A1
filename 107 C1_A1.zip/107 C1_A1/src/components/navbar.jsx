import "./Navbar.css";

function Navbar(){
    return (
    <div className="navbar">
        <h1>The menu will be here</h1>
    </div>
    );
}

export default Navbar;